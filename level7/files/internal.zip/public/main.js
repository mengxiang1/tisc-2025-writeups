const statusEl = document.getElementById("stack_status");
const healthStatusEl = document.getElementById("health_status");
const urlInput = document.getElementById("url_input");

function get_stack() {
    fetch(`/api/generate-stack?api_key=${apiKey}`)
        .then(res => res.json())
        .then(data => {
            if (data.stackId) {
                statusEl.textContent = `Stack created: ${data.stackId}`;
            } else {
                statusEl.textContent = `Error: ${data.error || 'Unknown'}`;
                console.error(data);
            }
        })
        .catch(err => {
            statusEl.textContent = "Request failed";
            console.error(err);
        });
}

function check_url() {
    const url = urlInput.value;
    if (!url) {
        healthStatusEl.textContent = "Please enter a URL";
        return;
    }

    fetch(`/api/healthcheck?url=${encodeURIComponent(url)}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === "up") {
                healthStatusEl.textContent = "Site is up";
            } else {
                healthStatusEl.textContent = `Site is down: ${data.error}`;
            }
        })
        .catch(err => {
            healthStatusEl.textContent = "Healthcheck failed";
            console.error(err);
        });
}
