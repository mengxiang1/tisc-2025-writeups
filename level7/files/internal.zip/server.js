import express from 'express';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = 3000;
// Insert API url here from API Gateway
const API_BASE = "https://8u7sima66a.execute-api.ap-southeast-1.amazonaws.com"; 

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });

app.get('/api/healthcheck', async (req, res) => {
    const target_url = req.query.url;
    if (!target_url) return res.status(400).json({ error: "Missing url param" });

    try {
        const response = await fetch(target_url);
        const text = await response.text();
        res.json({ status: "up", content: text });
    } catch {
        res.json({ status: "down", error: "fetch failed" });
    }
});

app.get('/api/generate-stack', async (req, res) => {
    const apiKey = req.query.api_key;
    if (!apiKey) return res.status(400).json({ error: "Missing API key" });

    try {
        const response = await fetch(`${API_BASE}/dev/generate-stack`, {
            headers: { "x-api-key": apiKey }
        });
        const data = await response.json();
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: "Stack creation failed", detail: e.message });
    }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});